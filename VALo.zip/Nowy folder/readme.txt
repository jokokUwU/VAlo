run load_driver.bat as administrator to load driver
run ItsGamerDoc.exe to start cheat

unloading driver:
run unload_driver.bat as admin